package com.zte.usee.P2._123456;

// imports
import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

import com.zte.mashup.engine.common.util.EngineUtils;
import com.zte.mashup.engine.spi.IServiceContext;
import com.zte.mashup.engine.session.UseeSession;
import com.zte.mashup.engine.trace.ServiceInputParam;
import com.zte.mashup.engine.trace.ServiceOutputParam;
import com.zte.mashup.engine.trace.ServiceTrace;
import com.zte.mashup.engine.trace.ServiceVariable;
import com.zte.mashup.serviceflow.execution.ProcessBase;
import com.zte.mashup.engine.common.EngineConstants;


@SuppressWarnings("unchecked")
public class Process extends ProcessBase {


    private List<ServiceInputParam> inputParamList;
	private List<ServiceOutputParam> outputParamList;
	private List<ServiceVariable> variableList;
	

	// FTL:variables start
	
	private Integer serviceKey = 0;
	private String callingNumber = "";
	private String calledNumber = "";
	private String translatedNumber = "";
	private Integer callCost = 0;
	private Integer timeLen = 0;
	private String IPAddress = "";
	private String IP_Str = "";
	private String CountryName = "";
	private String Country_str = "";
	
	
	public void setServiceKey(Integer serviceKey) {
		this.serviceKey = serviceKey;
	}

	public Integer getServiceKey() {
		return this.serviceKey;
	}
	public void setCallingNumber(String callingNumber) {
		this.callingNumber = callingNumber;
	}

	public String getCallingNumber() {
		return this.callingNumber;
	}
	public void setCalledNumber(String calledNumber) {
		this.calledNumber = calledNumber;
	}

	public String getCalledNumber() {
		return this.calledNumber;
	}
	public void setTranslatedNumber(String translatedNumber) {
		this.translatedNumber = translatedNumber;
	}

	public String getTranslatedNumber() {
		return this.translatedNumber;
	}
	public void setCallCost(Integer callCost) {
		this.callCost = callCost;
	}

	public Integer getCallCost() {
		return this.callCost;
	}
	public void setTimeLen(Integer timeLen) {
		this.timeLen = timeLen;
	}

	public Integer getTimeLen() {
		return this.timeLen;
	}
	public void setIPAddress(String IPAddress) {
		this.IPAddress = IPAddress;
	}

	public String getIPAddress() {
		return this.IPAddress;
	}
	public void setIP_Str(String IP_Str) {
		this.IP_Str = IP_Str;
	}

	public String getIP_Str() {
		return this.IP_Str;
	}
	public void setCountryName(String CountryName) {
		this.CountryName = CountryName;
	}

	public String getCountryName() {
		return this.CountryName;
	}
	public void setCountry_str(String Country_str) {
		this.Country_str = Country_str;
	}

	public String getCountry_str() {
		return this.Country_str;
	}
	
		
	private void setDefaultValue() {
		this.IPAddress = "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:web=\"http://www.webservicex.net/\">    <soapenv:Header/>    <soapenv:Body>       <web:GetGeoIP>          <!--Optional:-->          <web:IPAddress>?</web:IPAddress>       </web:GetGeoIP>    </soapenv:Body> </soapenv:Envelope>";
		this.CountryName = "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:web=\"http://www.webservicex.net/\">    <soapenv:Header/>    <soapenv:Body>       <web:GetGeoIPResponse>          <!--Optional:-->          <web:GetGeoIPResult>             <web:ReturnCode>?</web:ReturnCode>             <!--Optional:-->             <web:IP>?</web:IP>             <!--Optional:-->             <web:ReturnCodeDetails>?</web:ReturnCodeDetails>             <!--Optional:-->             <web:CountryName>?</web:CountryName>             <!--Optional:-->             <web:CountryCode>?</web:CountryCode>          </web:GetGeoIPResult>       </web:GetGeoIPResponse>    </soapenv:Body> </soapenv:Envelope>";
		this.Country_str = "none";
	}
	
	// FTL:add session variable
	private void initSessionVariables() {
	 
	 	if(null != context.getUseeSession()){
		}
	}
	// FTL:add session variable end
	

	@Override
	public Map<String, Object> getProcessVariables() {
		Map<String, Object> varMap = new HashMap<String, Object>();

		varMap.put("serviceKey", this.serviceKey);
		varMap.put("callingNumber", this.callingNumber);
		varMap.put("calledNumber", this.calledNumber);
		varMap.put("translatedNumber", this.translatedNumber);
		varMap.put("callCost", this.callCost);
		varMap.put("timeLen", this.timeLen);
		varMap.put("IPAddress", this.IPAddress);
		varMap.put("IP_Str", this.IP_Str);
		varMap.put("CountryName", this.CountryName);
		varMap.put("Country_str", this.Country_str);
		
		
		return varMap;
	}
	
	// FTL:variables end
	
	// FTL:params start
	@Override
	public Map<String, Object> getProcessInputParams() {
		Map<String, Object> inputParamsMap = new HashMap<String, Object>();
		inputParamsMap.put("IP", this.getIP_Str());
		return inputParamsMap;
	}
    @Override
	public Map<String, Object> getProcessOutputParams() {
		Map<String, Object> outputParamsMap = new HashMap<String, Object>();
		Object value_Country_out;
		try{
			value_Country_out = this.getCountry_str();		
		}
		catch(Exception e)
		 {
			value_Country_out = null;
			LOGGER.error("failed to get process variable : Country_str, maybe this is a session variable and session is timeout or closed manually.", e);
		 }	
		outputParamsMap.put("Country_out", value_Country_out);
		return outputParamsMap;
	}
	
	@Override
	public Map<String, Object> getServiceOutput() {
        
		Map<String, Object> output = new HashMap<String, Object>();
        if(EngineConstants.InstanceStatus.FINISH.equals(context.getInstanceStatus())){
            Object value_Country_out;
            try{
                value_Country_out = getCountry_str();      
            }
            catch(IllegalStateException e)
            {
                value_Country_out = null;
                LOGGER.error("failed to get process variable : Country_str, maybe this is a session variable and session is timeout or closed manually.", e);
            }       
            output.put("Country_out", value_Country_out);
            serviceOutputParamInstance(output);         
        }

		return output;
	}
	
	
	
	private void serviceOutputParamInstance(Map output) {
		if (context.isServiceTraceSaved()) {
			outputParamList = new ArrayList<ServiceOutputParam>();
			ServiceTrace trace = context.getServiceTrace();
			trace.setOutputParams(outputParamList);
			ServiceOutputParam Country_out = new ServiceOutputParam();
			outputParamList.add(Country_out);
			Country_out.setParamName("Country_out");
			Country_out.setVariableName("Country_str");
			Country_out.setDataType("String");
			Country_out.setParamValue(EngineUtils.javaObjectToString(output.get("Country_out")));
		}
	}
	// FTL:params end

	public Process(IServiceContext context) {
		super(context);
        setDefaultValue();
        initSessionVariables();		
	}
	
	@Override
	protected void setTraceVariableInstance() {
		if (context.isServiceTraceSaved()) {
			variableList = new ArrayList<ServiceVariable>();
			ServiceTrace trace = context.getServiceTrace();
			trace.setVariables(variableList);
		    
            ServiceVariable serviceKey = new ServiceVariable();
            variableList.add(serviceKey);
            serviceKey.setVariableName("serviceKey");
            serviceKey.setDataType("Integer");		    
			try
			{
				serviceKey.setVariableValue(EngineUtils.javaObjectToString(getServiceKey()));	
			}
			catch(IllegalStateException e)
			{
			    LOGGER.warn("failed to get process variable : serviceKey, maybe this is a session variable and session is timeout or closed manually.", e);
			}	
		    
            ServiceVariable callingNumber = new ServiceVariable();
            variableList.add(callingNumber);
            callingNumber.setVariableName("callingNumber");
            callingNumber.setDataType("String");		    
			try
			{
				callingNumber.setVariableValue(EngineUtils.javaObjectToString(getCallingNumber()));	
			}
			catch(IllegalStateException e)
			{
			    LOGGER.warn("failed to get process variable : callingNumber, maybe this is a session variable and session is timeout or closed manually.", e);
			}	
		    
            ServiceVariable calledNumber = new ServiceVariable();
            variableList.add(calledNumber);
            calledNumber.setVariableName("calledNumber");
            calledNumber.setDataType("String");		    
			try
			{
				calledNumber.setVariableValue(EngineUtils.javaObjectToString(getCalledNumber()));	
			}
			catch(IllegalStateException e)
			{
			    LOGGER.warn("failed to get process variable : calledNumber, maybe this is a session variable and session is timeout or closed manually.", e);
			}	
		    
            ServiceVariable translatedNumber = new ServiceVariable();
            variableList.add(translatedNumber);
            translatedNumber.setVariableName("translatedNumber");
            translatedNumber.setDataType("String");		    
			try
			{
				translatedNumber.setVariableValue(EngineUtils.javaObjectToString(getTranslatedNumber()));	
			}
			catch(IllegalStateException e)
			{
			    LOGGER.warn("failed to get process variable : translatedNumber, maybe this is a session variable and session is timeout or closed manually.", e);
			}	
		    
            ServiceVariable callCost = new ServiceVariable();
            variableList.add(callCost);
            callCost.setVariableName("callCost");
            callCost.setDataType("Integer");		    
			try
			{
				callCost.setVariableValue(EngineUtils.javaObjectToString(getCallCost()));	
			}
			catch(IllegalStateException e)
			{
			    LOGGER.warn("failed to get process variable : callCost, maybe this is a session variable and session is timeout or closed manually.", e);
			}	
		    
            ServiceVariable timeLen = new ServiceVariable();
            variableList.add(timeLen);
            timeLen.setVariableName("timeLen");
            timeLen.setDataType("Integer");		    
			try
			{
				timeLen.setVariableValue(EngineUtils.javaObjectToString(getTimeLen()));	
			}
			catch(IllegalStateException e)
			{
			    LOGGER.warn("failed to get process variable : timeLen, maybe this is a session variable and session is timeout or closed manually.", e);
			}	
		    
            ServiceVariable IPAddress = new ServiceVariable();
            variableList.add(IPAddress);
            IPAddress.setVariableName("IPAddress");
            IPAddress.setDataType("String");		    
			try
			{
				IPAddress.setVariableValue(EngineUtils.javaObjectToString(getIPAddress()));	
			}
			catch(IllegalStateException e)
			{
			    LOGGER.warn("failed to get process variable : IPAddress, maybe this is a session variable and session is timeout or closed manually.", e);
			}	
		    
            ServiceVariable IP_Str = new ServiceVariable();
            variableList.add(IP_Str);
            IP_Str.setVariableName("IP_Str");
            IP_Str.setDataType("String");		    
			try
			{
				IP_Str.setVariableValue(EngineUtils.javaObjectToString(getIP_Str()));	
			}
			catch(IllegalStateException e)
			{
			    LOGGER.warn("failed to get process variable : IP_Str, maybe this is a session variable and session is timeout or closed manually.", e);
			}	
		    
            ServiceVariable CountryName = new ServiceVariable();
            variableList.add(CountryName);
            CountryName.setVariableName("CountryName");
            CountryName.setDataType("String");		    
			try
			{
				CountryName.setVariableValue(EngineUtils.javaObjectToString(getCountryName()));	
			}
			catch(IllegalStateException e)
			{
			    LOGGER.warn("failed to get process variable : CountryName, maybe this is a session variable and session is timeout or closed manually.", e);
			}	
		    
            ServiceVariable Country_str = new ServiceVariable();
            variableList.add(Country_str);
            Country_str.setVariableName("Country_str");
            Country_str.setDataType("String");		    
			try
			{
				Country_str.setVariableValue(EngineUtils.javaObjectToString(getCountry_str()));	
			}
			catch(IllegalStateException e)
			{
			    LOGGER.warn("failed to get process variable : Country_str, maybe this is a session variable and session is timeout or closed manually.", e);
			}	
		 
		}
	}
	


}