package com.zte.usee.P2._123456;
// imports
import static com.zte.mashup.serviceflow.execution.utils.NodeUtils.*;
import static com.zte.mashup.serviceflow.execution.utils.XPathNodeUtils.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.dom4j.Document;

import com.zte.mashup.common.soap.Dom4jDocumentUtils;
import com.zte.mashup.engine.common.util.EngineUtils;
import com.zte.mashup.engine.session.UseeSession.SessionStatus;
import com.zte.mashup.serviceflow.execution.ProcessBase;
import com.zte.mashup.serviceflow.execution.Router;
import com.zte.mashup.serviceflow.execution.utils.ServiceLogRecordUtils;
import com.zte.mashup.serviceflow.execution.XPathNodeBase;

/**
 * Node name : XPath1
 * Node type : XPath
 */
@SuppressWarnings("unchecked")
public class UseeNode6 extends XPathNodeBase {

	public UseeNode6(ProcessBase process) {
		super(process, 6L, "UseeNode6", "XPath1");
	}

    @Override
    public void initRouter() {
        try
        {
            // router
						addRouter(new Router(Router.NOCOND, !hasException && !isTimeout, new UseeNode3(process)));
        }
        catch (Exception e)
        {
            hasException = true;
            Throwable firstCause = EngineUtils.getFirstCause(e);
            errorMessage = EngineUtils.stackToString(firstCause, 4000);
            ServiceLogRecordUtils.serviceMsgLog(this.className, e);
            sendErrorMsgToMtrace(errorMessage);
            clearRouter();
        }   
    }
	@Override
	public void executeBusiness() throws Exception {
		// /*breakpoint marker*/
		String expression1 = "";
		String operParam1 = "$IPAddress";
		String outputVar1 = ((Process)process).getIP_Str();
		handlerXPathWrite(1L,operParam1, expression1, outputVar1);
		hasFinExec = true;
	}
	
	public void handlerXPathRead(Long seq, String operParam, String expression, String outputVar) throws Exception
	{
		String xml = (String)process.getParamValue(operParam);
		Map<String, String> inMap = new HashMap<String, String>();
		Map<String, String> outMap = new HashMap<String, String>();
		String xpath = getEvaluatedXpath(expression, process);
		inMap.put("input" + seq, xpath);
		if (ServiceLogRecordUtils.isServiceMsgLogEnabled()) {
			ServiceLogRecordUtils.serviceMsgLog("execute xpathItem \""+ expression + "\"");
		}
		itemInputInstance(seq, inMap);

		if ((xpath != null) && (xpath.length() > 0)) {
			List<String> list = Dom4jDocumentUtils.getValueByXPath(xml, xpath);
			String output = "";
			if ((list != null) && (!list.isEmpty())) {
				output = list.get(0);
			}
			process.setParamValue(outputVar, output);
			outMap.put("output" + seq, output);
			if (ServiceLogRecordUtils.isServiceMsgLogEnabled()) {
				Map<String, Object> varChangedMap = new HashMap<String, Object>();
				varChangedMap.put(outputVar, output);
				ServiceLogRecordUtils.serviceMsgLogForVariableChanged(varChangedMap);
			}
			itemOutputInstance(outMap);
		}
	}
	
	public void handlerXPathWrite(Long seq, String operParam, String expression, String outputVar) throws Exception
	{
		String xml = (String)process.getParamValue(operParam);
		Map<String, String> inMap = new HashMap<String, String>();
		Map<String, String> outMap = new HashMap<String, String>();
		String xpath = getEvaluatedXpath(expression, process);
		inMap.put("input" + seq, xpath);
		if (ServiceLogRecordUtils.isServiceMsgLogEnabled()) {
			ServiceLogRecordUtils.serviceMsgLog("execute xpathItem \""+ expression + "\"");
		}
		itemInputInstance(seq, inMap);
		
		Document doc = getDocument4String(xml);
		if ((xpath != null) && (xpath.length() > 0)) {
			String value = (String) process.getParamValue(outputVar);
			Dom4jDocumentUtils.setValueByXPath(doc, xpath, value);
			outMap.put("ouput" + seq, value);
			String output = getString4Document(doc);
			process.setParamValue(operParam, output);
			if (ServiceLogRecordUtils.isServiceMsgLogEnabled()) {
				Map<String, Object> varChangedMap = new HashMap<String, Object>();
				varChangedMap.put(operParam, output);
				ServiceLogRecordUtils.serviceMsgLogForVariableChanged(varChangedMap);
			}
			itemOutputInstance(outMap);
		}
	}
}

