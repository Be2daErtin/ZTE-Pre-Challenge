package com.zte.usee.P2._123456;
import static com.zte.mashup.serviceflow.execution.utils.NodeUtils.*;
// imports
import java.util.HashMap;
import java.util.Map;

import com.zte.mashup.engine.common.util.EngineUtils;
import com.zte.mashup.engine.session.UseeSession.SessionStatus;
import com.zte.mashup.serviceflow.execution.ProcessBase;
import com.zte.mashup.serviceflow.execution.Router;
import com.zte.mashup.serviceflow.execution.WebServiceNodeBase;
import com.zte.mashup.serviceflow.execution.utils.ServiceLogRecordUtils;

/**
 * Node name : geoipservice.asmx1
 * Node type : Webservice
 */
@SuppressWarnings("unchecked")
public class UseeNode3 extends WebServiceNodeBase {

	public UseeNode3(ProcessBase process) {
		super(process, 3L, "UseeNode3", "geoipservice.asmx1");
	}

    @Override
    public void initRouter() {
        try
        {
            // router
						addRouter(new Router(Router.NOCOND, !hasException && !isTimeout, new UseeNode9(process)));
        }
        catch (Exception e)
        {
            hasException = true;
            Throwable firstCause = EngineUtils.getFirstCause(e);
            errorMessage = EngineUtils.stackToString(firstCause, 4000);
            ServiceLogRecordUtils.serviceMsgLog(this.className, e);
            sendErrorMsgToMtrace(errorMessage);
            clearRouter();
        }   
    }	
	public void executeBusiness() throws Exception{
		// /*breakpoint marker*/
		if (ServiceLogRecordUtils.isServiceMsgLogEnabled()) {
			ServiceLogRecordUtils.serviceMsgLog("get soap message");
		}
		String action = "GetGeoIP";
		String endPoint = getServicePropValue("@url", "geoipservice.asmx", "GeoIPServiceSoap", action);
		String request = ((Process)process).getIPAddress();

		String response = sendSoapMsg(endPoint, action, request);
		
		((Process)process).setCountryName(response);
		hasFinExec = true;
	}
	

}

