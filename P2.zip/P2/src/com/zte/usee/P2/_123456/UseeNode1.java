package com.zte.usee.P2._123456;
// imports
import static com.zte.mashup.serviceflow.execution.utils.NodeUtils.*;

import java.util.HashMap;
import java.util.Map;

import com.zte.mashup.engine.common.util.EngineUtils;
import com.zte.mashup.engine.session.UseeSession.SessionStatus;
import com.zte.mashup.serviceflow.execution.ProcessBase;
import com.zte.mashup.serviceflow.execution.Router;
import com.zte.mashup.serviceflow.execution.StartNodeBase;
import com.zte.mashup.serviceflow.execution.utils.ServiceLogRecordUtils;

/**
 * Node name : StartNode
 * Node type : Start node
 */
@SuppressWarnings("unchecked")
public class UseeNode1 extends StartNodeBase {

	public UseeNode1(ProcessBase process) {
		super(process,1L,"UseeNode1","StartNode");
	}

    @Override
    public void initRouter() {
        try
        {
            // router
						addRouter(new Router(Router.NOCOND, !hasException && !isTimeout, new UseeNode6(process)));
        }
        catch (Exception e)
        {
            hasException = true;
            Throwable firstCause = EngineUtils.getFirstCause(e);
            errorMessage = EngineUtils.stackToString(firstCause, 4000);
            ServiceLogRecordUtils.serviceMsgLog(this.className, e);
            sendErrorMsgToMtrace(errorMessage);
            clearRouter();
        }   
    }	@Override
	public void executeBusiness() throws Exception{
		// /*breakpoint marker*/
		super.executeBusiness();
	}
	
}