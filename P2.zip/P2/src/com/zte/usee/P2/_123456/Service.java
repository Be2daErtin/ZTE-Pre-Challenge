package com.zte.usee.P2._123456;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.zte.mashup.commons.lang.GenericsCaster;
import com.zte.mashup.engine.business.model.ReturnEntity;
import com.zte.mashup.engine.common.EngineConstants;
import com.zte.mashup.engine.common.util.EngineUtils;
import com.zte.mashup.engine.session.UseeSession;
import com.zte.mashup.engine.spi.IServiceContext;
import com.zte.mashup.engine.trace.ServiceInputParam;
import com.zte.mashup.engine.trace.ServiceTrace;
import com.zte.mashup.serviceflow.execution.Node;
import com.zte.mashup.serviceflow.execution.ProcessBase;
import com.zte.mashup.serviceflow.execution.ServiceBase;
import com.zte.mashup.serviceflow.execution.utils.ServiceLogRecordUtils;

public class Service extends ServiceBase {

	private List<ServiceInputParam> inputParamList;

	@Override
	public boolean hasExceptionNode() {
		return false;
	}	

	public Service() {
	}

	public void init() {
	}

	public void destroy() {
	}

	public void setContext(IServiceContext context) {
		this.context = context;
	}

	// FTL:entrance start
	// normalStartMethod
	public Map normalStart(UseeSession session, Map input) {
		context.getServiceStater().begin();
		processBase = new Process(context);
		Process process = GenericsCaster.unsafeCast(processBase);
	    
		processBase.setExceptionNode(null);
	    
		//input
		logServiceInfo();
		process.setIP_Str(input.get("IP") == null ? null: (String) input.get("IP"));
		serviceInputParamInstance(input);
		if (ServiceLogRecordUtils.isServiceMsgLogEnabled()) {
		Map<String, Object> inputMap = new HashMap<String, Object>();
		inputMap.put("IP", process.getIP_Str());
		ServiceLogRecordUtils.serviceMsgLog(processBase.getProcessInputParams(), "the init param map is ");
		ServiceLogRecordUtils.serviceMsgLogForVariableChanged(inputMap);
		}
		processBase.setNode(new UseeNode1(processBase));
		return processBase.execute();

		//variable
		//serviceVariableInstance();
		//return getOutput(processBase);
	}
	
	
	
	// exceptionNodeMethod
	public Map execExceptionUseeNode(UseeSession session, Map input) {
		
		if (ServiceLogRecordUtils.isServiceMsgLogEnabled()) {
			ServiceLogRecordUtils.serviceMsgLog("enter execExceptionUseeNode method.");
			if(input.get("execExceptionSource") != null){
				ServiceLogRecordUtils.serviceMsgLog("Exception Source : "+ input.get("execExceptionSource"));
			}
		}
		if (ServiceLogRecordUtils.isServiceMsgLogEnabled()) {
			ServiceLogRecordUtils.serviceMsgLog("Exception node does not exist, execute Instance stopped");
		}
		return new HashMap();
	}
	// FTL:service params instance start
	private void serviceInputParamInstance(Map input) {
		if (context.isServiceTraceSaved()) {
			inputParamList = new ArrayList<ServiceInputParam>();
			ServiceTrace trace = context.getServiceTrace();
			trace.setInputParams(inputParamList);
			ServiceInputParam IP = new ServiceInputParam();
			inputParamList.add(IP);
			IP.setParamName("IP");
			IP.setVariableName("IP_Str");
			IP.setDataType("String");
			IP.setParamValue(EngineUtils.javaObjectToString(input.get("IP")));
		}
	}
	// FTL:service params instance end
	// FTL:entrance end

}
